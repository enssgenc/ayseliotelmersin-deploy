(function () {
  'use strict';
  var key = 'ayseli_tracking_consent_v1';
  var changed = 'ayseli:tracking-consent';
  var mobileLabel = 'AW-18423132568/MQiNCL_22aUdEJjj6tBE';
  var landlineLabel = 'AW-18423132568/uWNFCNXV3ewcEJjj6tBE';
  var whatsappLabel = 'AW-18423132568/rCYmCI_m0uwcEJjj6tBE';
  var saved = null;
  var metaLoaded = false;
  var phoneConfigured = false;
  try {
    var stored = window.localStorage.getItem(key);
    if (stored === 'granted' || stored === 'denied') saved = stored;
  } catch (_) {}

  window.dataLayer = window.dataLayer || [];
  window.gtag = window.gtag || function () { window.dataLayer.push(arguments); };
  function google() {
    try {
      if (typeof window.gtag === 'function') { window.gtag.apply(window, arguments); return true; }
    } catch (_) {}
    return false;
  }
  function settings(value) {
    return {ad_storage:value, analytics_storage:value, ad_user_data:value, ad_personalization:value};
  }
  var defaults = settings('denied');
  defaults.wait_for_update = 500;
  google('consent', 'default', defaults);
  if (saved === 'granted') google('consent', 'update', settings('granted'));

  function clearTrackingStorage() {
    var names = [];
    try {
      names = document.cookie.split(';').map(function (c) { return c.split('=')[0].trim(); })
        .filter(function (name) { return /^(_ga(?:_|$)|_gid$|_gat|_gcl_|_fbp$|_fbc$)/.test(name); });
    } catch (_) {}
    var parts = window.location.hostname.split('.');
    names.forEach(function (name) {
      var expired = name + '=; Max-Age=0; path=/; SameSite=Lax';
      try {
        document.cookie = expired;
        for (var i=0; i<parts.length-1; i++) {
          var domain = parts.slice(i).join('.');
          document.cookie = expired + '; domain=' + domain;
          document.cookie = expired + '; domain=.' + domain;
        }
      } catch (_) {}
    });
    try {
      ['_gcl_ls','lastExternalReferrer','lastExternalReferrerTime'].forEach(function (k) { window.localStorage.removeItem(k); });
    } catch (_) {}
  }
  function meta() {
    try { if (typeof window.fbq === 'function') window.fbq.apply(window, arguments); } catch (_) {}
  }
  function enableConsentedTags() {
    if (!phoneConfigured) {
      google('config', 'AW-18423132568/MQW5CI6L3ewcEJjj6tBE', {phone_conversion_number:'0555 961 01 36'});
      phoneConfigured = true;
    }
    if (metaLoaded) { meta('consent','grant'); return; }
    if (!window.fbq) {
      var fbq = window.fbq = function () {
        if (fbq.callMethod) fbq.callMethod.apply(fbq, arguments);
        else fbq.queue.push(arguments);
      };
      window._fbq = window._fbq || fbq;
      fbq.push = fbq; fbq.loaded = true; fbq.version = '2.0'; fbq.queue = [];
      var script = document.createElement('script');
      script.async = true; script.src = 'https://connect.facebook.net/en_US/fbevents.js';
      document.head.appendChild(script);
    }
    meta('consent','grant'); meta('init','3193960627659486'); meta('track','PageView');
    metaLoaded = true;
  }
  function update(state, persist) {
    saved = state;
    if (persist) { try { window.localStorage.setItem(key,state); } catch (_) {} }
    google('consent','update',settings(state === 'granted' ? 'granted' : 'denied'));
    if (state === 'granted') enableConsentedTags();
    else { meta('consent','revoke'); clearTrackingStorage(); }
    window.dispatchEvent(new CustomEvent(changed));
  }
  window.ayseliGetTrackingConsent = function () { return saved; };
  window.ayseliSetTrackingConsent = function (granted) { update(granted ? 'granted' : 'denied',true); };
  window.addEventListener('storage',function (event) {
    if (event.key !== key && event.key !== null) return;
    update(event.newValue === 'granted' || event.newValue === 'denied' ? event.newValue : null,false);
  });

  function conversion(label,url) {
    var done=false, timer;
    function go() {
      if (done) return;
      done=true; window.clearTimeout(timer);
      if (typeof url === 'string' && url) window.location.href=url;
    }
    if (url) timer=window.setTimeout(go,1500);
    var event={send_to:label,event_callback:go,event_timeout:1300};
    if (label === whatsappLabel) { event.value=1;event.currency='TRY'; }
    if (!google('event','conversion',event)) go();
    return false;
  }
  window.gtag_report_mobile_conversion = function () { return conversion(mobileLabel); };
  window.gtag_report_landline_conversion = function (url) { return conversion(landlineLabel,url); };
  window.gtag_report_whatsapp_conversion = function (url) { return conversion(whatsappLabel,url); };

  window.ayseliMountConsent = function () {
    if (document.getElementById('cookieConsent')) return;
    var footer = document.querySelector('footer');
    if (!footer) return;
    var open = false, restoreFocus = false;
    var trigger = document.createElement('button');
    trigger.type='button'; trigger.id='cookieSettingsButton'; trigger.className='ayseli-cookie-settings';
    trigger.textContent='Çerez tercihleri';
    var privacy=footer.querySelector('button');
    if (privacy) privacy.parentElement.insertBefore(trigger,privacy.nextSibling);
    else footer.appendChild(trigger);
    var panel = document.createElement('aside');
    panel.id='cookieConsent'; panel.className='ayseli-consent'; panel.setAttribute('role','dialog');
    panel.setAttribute('aria-modal','false'); panel.setAttribute('aria-labelledby','cookieConsentTitle');
    panel.setAttribute('aria-describedby','cookieConsentDescription');
    panel.innerHTML='<div class="ayseli-consent-copy"><h2 id="cookieConsentTitle">Deneyiminizi birlikte iyileştirelim</h2><p id="cookieConsentDescription">Siteyi geliştirmek ve reklamlarımızın performansını ölçmek için analiz ve reklam çerezlerini yalnızca izninizle kullanıyoruz.</p><p class="ayseli-consent-note">Tercihinizi istediğiniz zaman değiştirebilirsiniz.</p></div><div class="ayseli-consent-actions"><button id="rejectTracking" type="button" class="ayseli-cookie-button">Yalnızca gerekli</button><button id="acceptTracking" type="button" class="ayseli-cookie-button ayseli-cookie-primary">Tümünü kabul et</button></div>';
    document.body.appendChild(panel);
    var status = document.createElement('span');
    status.className='ayseli-consent-status'; status.setAttribute('role','status');
    document.body.appendChild(status);
    function render() {
      panel.hidden = saved !== null && !open;
      document.documentElement.classList.toggle('ayseli-consent-open',!panel.hidden);
    }
    function show() {
      open=true; restoreFocus=true; render();
      panel.querySelector('button').focus({preventScroll:true});
    }
    function choose(granted) {
      open=false;
      window.ayseliSetTrackingConsent(granted);
      status.textContent=granted?'Analiz ve reklam çerezlerine izin verildi.':'Yalnızca gerekli çerezler kullanılıyor.';
      if (restoreFocus) { trigger.focus({preventScroll:true}); restoreFocus=false; }
    }
    trigger.addEventListener('click',show);
    panel.querySelector('#rejectTracking').addEventListener('click',function () { choose(false); });
    panel.querySelector('#acceptTracking').addEventListener('click',function () { choose(true); });
    panel.addEventListener('keydown',function (event) {
      if (event.key === 'Escape' && open && saved !== null) {
        open=false;render();trigger.focus({preventScroll:true});restoreFocus=false;
      }
    });
    window.addEventListener(changed,render);
    window.addEventListener('ayseli:open-consent',show);
    render();
  };

  if (saved !== 'granted') clearTrackingStorage();
  google('js',new Date());
  google('config','G-VYRQ2N81DB');
  google('config','AW-18423132568');
  var googleTag=document.createElement('script');
  googleTag.async=true;googleTag.src='https://www.googletagmanager.com/gtag/js?id=G-VYRQ2N81DB';
  document.head.appendChild(googleTag);
  if (saved === 'granted') enableConsentedTags();
  var stylesheet=document.createElement('link');
  stylesheet.rel='stylesheet';stylesheet.href='/site-preferences-a61371ab8faf.css';document.head.appendChild(stylesheet);
})();
